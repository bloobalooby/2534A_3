import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.userinterface.R;

public class DashboardActivity extends AppCompatActivity {

    Button submitRequestBtn, viewRequestsBtn;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        submitRequestBtn = findViewById(R.id.submitRequest);
        viewRequestsBtn = findViewById(R.id.viewRequests);

        submitRequestBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DashboardActivity.this, SubmitRequestActivity.class);
                startActivity(intent);
            }
        });

        viewRequestsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DashboardActivity.this, ViewRequestsActivity.class);
                startActivity(intent);
            }
    });
    }
}
