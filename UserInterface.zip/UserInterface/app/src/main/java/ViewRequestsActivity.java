import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.example.userinterface.R;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ViewRequestsActivity extends AppCompatActivity {

    RecyclerView requestRecyclerView;
    RequestAdapter adapter;
    List<RequestModel> requestList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_requests);

        requestRecyclerView = findViewById(R.id.requestRecyclerView);
        requestList = loadRequestsFromPrefs();

        adapter = new RequestAdapter(requestList, this::showCancelConfirmation);
        requestRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        requestRecyclerView.setAdapter(adapter);
    }

    private void showCancelConfirmation(int position) {
        new AlertDialog.Builder(this)
                .setTitle("Cancel Request")
                .setMessage("Are you sure you want to cancel this request?")
                .setPositiveButton("Yes", (dialog, which) -> {
                    requestList.get(position).setStatus("Cancelled");
                    saveRequestsToPrefs(requestList);
                    adapter.notifyItemChanged(position);
                    Toast.makeText(this, "Request cancelled.", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("No", null)
                .show();
    }

    private List<RequestModel> loadRequestsFromPrefs() {
        SharedPreferences prefs = getSharedPreferences("RequestsData", MODE_PRIVATE);
        String data = prefs.getString("requestList", "");
        List<RequestModel> list = new ArrayList<>();

        for (String block : data.split("\n\n")) {
            String[] lines = block.split("\n");
            if (lines.length < 6) continue;
            list.add(new RequestModel(
                    lines[0].replace("Item Type: ", ""),
                    lines[1].replace("Item: ", ""),
                    lines[2].replace("Address: ", ""),
                    lines[3].replace("Date: ", ""),
                    lines[4].replace("Status: ", ""),
                    lines[5].replace("Price: ", "")
            ));
        }
        return list;
    }

    private void saveRequestsToPrefs(List<RequestModel> list) {
        SharedPreferences.Editor editor = getSharedPreferences("RequestsData", MODE_PRIVATE).edit();
        StringBuilder builder = new StringBuilder();

        for (RequestModel model : list) {
            builder.append("Item Type: ").append(model.getItemType()).append("\n")
                    .append("Item: ").append(model.getItemName()).append("\n")
                    .append("Address: ").append(model.getAddress()).append("\n")
                    .append("Date: ").append(model.getDate()).append("\n")
                    .append("Status: ").append(model.getStatus()).append("\n")
                    .append("Price: ").append(model.getPrice() != null ? model.getPrice() : "-").append("\n\n");
        }
        editor.putString("requestList", builder.toString());
        editor.apply();
    }
}