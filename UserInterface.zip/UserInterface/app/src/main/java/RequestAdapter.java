import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import com.example.userinterface.R;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class RequestAdapter extends RecyclerView.Adapter<RequestAdapter.ViewHolder>  {

    private List<RequestModel> requestList;
    private OnCancelClickListener cancelClickListener;

    public interface OnCancelClickListener {
        void onCancel(int position);
    }

    public RequestAdapter(List<RequestModel> requestList, OnCancelClickListener cancelClickListener) {
        this.requestList = requestList;
        this.cancelClickListener = cancelClickListener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.request_item_layout, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        RequestModel model = requestList.get(position);
        holder.itemType.setText("Item Type: " + model.getItemType());
        holder.itemName.setText("Item: " + model.getItemName());
        holder.date.setText("Date: " + model.getDate());
        holder.address.setText("Address: " + model.getAddress());
        holder.status.setText("Status: " + model.getStatus());
        holder.price.setText("Price: " + (model.getPrice() != null ? model.getPrice() : "-"));

        if ("Pending".equalsIgnoreCase(model.getStatus())) {
            holder.cancelBtn.setVisibility(View.VISIBLE);
            holder.cancelBtn.setOnClickListener(v -> cancelClickListener.onCancel(position));
        } else {
            holder.cancelBtn.setVisibility(View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        return requestList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView itemType, itemName, address, date, status, price;
        Button cancelBtn;

        public ViewHolder(View itemView) {
            super(itemView);
            itemType = itemView.findViewById(R.id.itemTypeText);
            itemName = itemView.findViewById(R.id.itemNameText);
            address = itemView.findViewById(R.id.addressText);
            date = itemView.findViewById(R.id.dateText);
            status = itemView.findViewById(R.id.statusText);
            price = itemView.findViewById(R.id.priceText);
            cancelBtn = itemView.findViewById(R.id.cancelButton);
        }
    }
}