public class RequestModel {
    private String itemType;
    private String itemName;
    private String date;
    private String address;
    private String status;
    private String price;

    public RequestModel(String itemType, String date, String address, String status, String price, String replace) {
        this.itemType = itemType;
        this.itemName = itemName;
        this.date = date;
        this.address = address;
        this.status = status;
        this.price = price;
    }

    public String getItemType() { return itemType; }
    public String getItemName() { return itemName; }
    public String getDate() { return date; }
    public String getAddress() { return address; }
    public String getStatus() { return status; }
    public String getPrice() { return price; }

    //cancel
    public void setStatus(String status) {
        this.status = status;
    }



}
