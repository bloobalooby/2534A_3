import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import com.example.userinterface.R;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SubmitRequestActivity extends AppCompatActivity {

    Spinner itemTypeSpinner, itemListSpinner;
    EditText addressEditText, dateEditText, notesEditText;
    Button submitRequestBtn;

    Map<String, List<String>> itemMap;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_submit_request);

        itemTypeSpinner = findViewById(R.id.itemTypeSpinner);
        itemListSpinner = findViewById(R.id.itemListSpinner);
        addressEditText = findViewById(R.id.address);
        dateEditText = findViewById(R.id.date);
        notesEditText = findViewById(R.id.notes);
        submitRequestBtn = findViewById(R.id.submitRequestBtn);

        //Populate item type and item list
        itemMap = new HashMap<>();

        itemMap.put("Clothing", List.of(
                "Cotton T-shirt", "Denim Jeans", "Hoodie Sweatshirt", "Polo Shirt", "Maxi Dress"));

        itemMap.put("Bag", List.of(
                "Leather Handbag", "Cotton Handbag", "Canvas Tote Bag", "Mini Backpack", "Crossbody Sling Bag"));

        // set up item spinner
        List<String> itemTypes = new ArrayList<>(itemMap.keySet());
        ArrayAdapter<String> itemTypeAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, itemTypes);
        itemTypeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        itemTypeSpinner.setAdapter(itemTypeAdapter);

        //change itemListSpinner based on selectes type
        itemTypeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedType = itemTypes.get(position);
                List<String> itemList = itemMap.get(selectedType);

                ArrayAdapter<String> itemListAdapter = new ArrayAdapter<>(SubmitRequestActivity.this,
                        android.R.layout.simple_spinner_item, itemList);
                itemListAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                itemListSpinner.setAdapter(itemListAdapter);
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        //handle submit button
        submitRequestBtn.setOnClickListener(v -> {
            String itemType = itemTypeSpinner.getSelectedItem().toString();
            String item = itemListSpinner.getSelectedItem().toString();
            String address = addressEditText.getText().toString().trim();
            String date = dateEditText.getText().toString().trim();
            String notes = notesEditText.getText().toString().trim();


            if(address.isEmpty()) {
                Toast.makeText(this, "Please enter the pickup address and date", Toast.LENGTH_SHORT).show();
                return;
            }

            // Save the request
            SharedPreferences prefs = getSharedPreferences("RequestsData", MODE_PRIVATE);
            SharedPreferences.Editor editor = prefs.edit();

            String oldRequests = prefs.getString("requestList", "");
            String newRequest = "Item Type: " + itemType +
                    "\nItem: " + item +
                    "\nAddress: " + address +
                    "\nDate: " + date +
                    (notes.isEmpty() ? "" : "\nNotes: " + notes) +
                    "\nStatus: Pending\n\n";

            editor.putString("requestList", oldRequests + newRequest);
            editor.apply();

            Toast.makeText(this, "Request submitted!", Toast.LENGTH_SHORT).show();

            // Optionally clear address
            addressEditText.setText("");
            dateEditText.setText("");
            notesEditText.setText("");
        });

    }
}
